SELECT FantasticJourneys.dbo.CUSTOMER.Customer_ID AS Customer_AK, FantasticJourneys.dbo.CUSTOMER.Customer_DOB, FantasticJourneys.dbo.CUSTOMER.Customer_Zip, 
FantasticJourneys.dbo.CUSTOMER.Customer_Gender,
FantasticJourneys.dbo.CUSTOMER.Customer_[State],
FantasticJourneys.dbo.MEMBERSHIP.Membership_YorN, FantasticJourneys.dbo.MEMBERSHIP.Membership_MembershipLevel,
FantasticJourneys.dbo.Membership.Membership_Discount,
FROM FantasticJourneys.dbo.CUSTOMER
INNER JOIN FantasticJourneys.dbo.MEMBERSHIP
ON FantasticJourneys.dbo.CUSTOMER.Membership_ID = FantasticJourneys.dbo.MEMBERSHIP.Membership_ID

SELECT FantasticJourneys.dbo.HOTEL.Hotel_ID AS Customer_AK, FantasticJourneys.dbo.HOTEL.Hotel_Name, FantasticJourneys.dbo.HOTEL.Hotel_State, FantasticJourneys.dbo.HOTEL.Hotel_ZipCode,
FantasticJourneys.dbo.RATING.Star_Rating, FantasticJourneys.dbo.RATING.Number_Of_Rooms
FROM FantasticJourneys.dbo.HOTEL
INNER JOIN FantasticJourneys.dbo.RATING
ON FantasticJourneys.dbo.HOTEL.Hotel_ID = FantasticJourneys.dbo.RATING.Rating_ID

SELECT FantasticJourneys.dbo.ROOM.Room_ID AS Room_AK, FantasticJourneys.dbo.ROOM.Room_Occupancy, FantasticJourneys.dbo.ROOM_TYPE.Room_Type_Bed_Type, FantasticJourneys.dbo.ROOM.Room_Type_Bed_Number
FROM FantasticJourneys.dbo.ROOM
INNER JOIN FantasticJourneys.dbo.ROOM_TYPE
ON FantasticJourneys.dbo.ROOM.Room_ID = FantasticJourneys.dbo.ROOM_TYPE.Room_ID








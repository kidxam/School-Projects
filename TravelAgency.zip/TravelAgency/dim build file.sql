CREATE TABLE DimDate
	(
	Date_SK				INT PRIMARY KEY, 
	Date				DATE,
	FullDate			NCHAR(10) ,-- Date in MM-dd-yyyy format
	DayOfMonth			INT , -- Field will hold day number of Month
	DayName				NVARCHAR(9), -- Contains name of the day, Sunday, Monday 
	DayOfWeek			INT,-- First Day Sunday=1 and Saturday=7
	DayOfWeekInMonth	INT, -- 1st Monday or 2nd Monday in Month
	DayOfWeekInYear		INT,
	DayOfQuarter		INT,
	DayOfYear			INT,
	WeekOfMonth			INT,-- Week Number of Month 
	WeekOfQuarter		INT, -- Week Number of the Quarter
	WeekOfYear			INT ,-- Week Number of the Year
	Month				INT, -- Number of the Month 1 to 12{}
	MonthName			NVARCHAR(9),-- January, February etc
	MonthOfQuarter		INT,-- Month Number belongs to Quarter
	Quarter				NCHAR(2),
	QuarterName			NVARCHAR(9) ,-- First,Second..
	Year				INT ,-- Year value of Date stored in Row
	YearName			CHAR(7) , -- CY 2017,CY 2018
	MonthYear			CHAR(10) , -- Jan-2018,Feb-2018
	MMYYYY				INT ,
	FirstDayOfMonth		DATE,
	LastDayOfMonth		DATE,
	FirstDayOfQuarter	DATE,
	LastDayOfQuarter	DATE,
	FirstDayOfYear		DATE,
	LastDayOfYear		DATE,
	IsHoliday			BIT,-- Flag 1=National Holiday, 0-No National Holiday
	IsWeekday			BIT,-- 0=Week End ,1=Week Day
	Holiday				NVARCHAR(50),--Name of Holiday in US
	Season				NVARCHAR(10)--Name of Season
	);
--
CREATE TABLE FactBill
	(
	Customer_SK 			INT NOT NULL
	Hotel_SK				INT NOT NULL,
	Room_SK					INT NOT NULL,
	Date_SK					INT NOT NULL,
	Bill_RoomCharge 		DECIMAL (7,2) CONSTRAINT nn_Bill_RoomCharge NOT NULL, 
	Bill_RoomServiceCharge 	DECIMAL (7,2) CONSTRAINT nn_Bill_ServiceCharge NOT NULL,
	Bill_BarCharge			DECIMAL (7,2) CONSTRAINT nn_Bill_BarCharge NOT NULL,
	Room_Type_Rate			INT CONSTRAINT nn_Room_Type_Rate NOT NULL,	
	Bill_RestaurantCharge 	DECIMAL (7,2) CONSTRAINT nn_Bill_Restaurant_Charge NOT NULL,
	Membership_Discount		NVARCHAR(5) NOT NULL,
	CONSTRAINT pk_FactBill PRIMARY KEY (Customer_SK,Room_SK,Hotel_Sk,Date_SK),
	CONSTRAINT fk_FactBill_DimDate FOREIGN KEY (Date_SK) REFERENCES DimDate(Date_SK),
	CONSTRAINT fk_FactBill_DimCustomer FOREIGN KEY (Customer_SK) REFERENCES DimCustomer(Customer_SK),
	CONSTRAINT fk_FactBill_DimRoom FOREIGN KEY (Room_SK) REFERENCES DimCourse(Room_SK),
	CONSTRAINT fk_FactBill_DimHotel FOREIGN KEY (Hotel_SK) REFERENCES DimStudent(Hotel_SK)
	);
--
CREATE TABLE DimCustomer
	(
	Customer_SK 				INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	Customer_AK 				INT NOT NULL,
	Customer_DOB				DATE CONSTRAINT nn_Customer_DOB NOT NULL,
	Zip							NVARCHAR(10) NOT NULL,
	Customer_State				NVARCHAR(25) NOT NULL,
	Membership_MembershipLevel	NVARCHAR(25) CONSTRAINT nn_Membership_MembershipLevel NOT NULL
	);
--	
CREATE TABLE DimHotel
	(
	Hotel_SK			INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	Hotel_AK			INT NOT NULL,
	Hotel_Name			NVARCHAR(25) CONSTRAINT nn_Hotel_Name NOT NULL,
	Hotel_State			NVARCHAR(13) CONSTRAINT nn_Hotel_State NOT NULL,
	Hotel_Zip			NVARCHAR(11) CONSTRAINT nn_Hotel_Zip NOT NULL,
	Hotel_NumberRooms	INT NCARCHAR(25) CONSTRAINT nn_Hotel_NumberRooms NOT NULL,
	Rating_StarRating	NVARCHAR(5) NOT NULL
	);
--
CREATE TABLE DimRoom
	(
	Room_SK				INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	Room_AK				INT NOT NULL,
	Room_Occupancy		INT CONSTRAINT nn_Room_OccupancyNOT NULL,
	Room_Type_BedType	NVARCHAR(50) CONSTRAINT nn_Room_Type_BedType NOT NULL,
	Room_Type_BedNumber	INT CONSTRAINT nn_Room_Type_BedNumber NOT NULL
	);
	
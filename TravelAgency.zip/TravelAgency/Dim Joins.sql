SELECT FantasticJourneys.dbo.Bill.Bill_ID AS Bill_ID_DD, FantasticJourneys.dbo.Bill.Bill_RoomCharge, 
		FantasticJourneys.dbo.Bill.Bill_RoomServiceCharge, FantasticJourneys.dbo.Bill.Bill_BarChange, FantasticJourneys.dbo.ROOM_TYPE.Room_Type_Rate,
		FantasticJourneys.dbo.Bill.Bill_RestaurantCharge, FantasticJourneys.dbo.Membership.Membership_Discount, FantasticJourneysDM.dbo.DimCustomer.Customer_SK,
		FantasticJourneysDM.dbo.DimRoom.Room_SK, FantasticJourneysDM.dbo.DimHotel.Hotel_SK, 
FantasticJourneysDM.dbo.DimDate.Date_SK
FROM FantasticJourneys.dbo.Bill
INNER JOIN FantasticJourneys.dbo.Booking
ON FantasticJourneys.dbo.Booking.Booking_ID = FantasticJourneys.dbo.Bill.Booking_ID
INNER JOIN FantasticJourneys.dbo.ROOM_TYPE
ON FantasticJourneys.dbo.ROOM_TYPE.Room_Type_ID = FantasticJourneys.dbo.BOOKING.Room_Type_ID
INNER JOIN FantasticJourneys.dbo.Customer
ON FantasticJourneys.dbo.Booking.Customer_ID = FantasticJourneys.dbo.Customer.Customer_ID
INNER JOIN FantasticJourneys.dbo.Membership
ON FantasticJourneys.dbo.Customer.Membership_ID = FantasticJourneys.dbo.Membership.Membership_ID
INNER JOIN FantasticJourneys.dbo.Room
ON FantasticJourneys.dbo.Room_Type.Room_Type_ID = FantasticJourneys.dbo.Room.Room_Type_ID
INNER JOIN FantasticJourneys.dbo.Hotel
ON FantasticJourneys.dbo.Hotel.Hotel_ID = FantasticJourneys.dbo.Room.Hotel_ID
INNER JOIN FantasticJourneysDM.dbo.DimCustomer
ON FantasticJourneysDM.dbo.DimCustomer.Customer_AK = FantasticJourneys.dbo.Customer.Customer_ID
INNER JOIN FantasticJourneysDM.dbo.DimHotel
ON FantasticJourneysDM.dbo.DimHotel.Hotel_AK = FantasticJourneys.dbo.HOTEL.Hotel_ID
INNER JOIN FantasticJourneysDM.dbo.DimRoom
ON FantasticJourneysDM.dbo.DimRoom.Room_AK = FantasticJourneys.dbo.ROOM.Room_ID
INNER JOIN FantasticJourneysDM.dbo.DimDate
ON FantasticJourneysDM.dbo.DimDate.Date = FantasticJourneys.dbo.Booking.Booking_ArrivalDate
--VIEW

--View that shows all customers that listed a zip code from Colorado

CREATE VIEW		[Colorodans]
AS 
SELECT			*
FROM			CUSTOMER
WHERE			Customer_Zip_Code BETWEEN 80001 AND 81658
WITH CHECK OPTION;

--View shows there are no customers that listed their zipcode as one from Colorado

SELECT *
FROM Colorodans
;

--STORED PROCEDURE
--Procedure will display every instance of a ski being rented for more than 10 days
--along with the name of the ski

CREATE PROCEDURE usp_SkiRented  
AS
BEGIN
		SELECT Ski_Name, Rental_Number_Of_Days, Rental_Day
		FROM RENTAL
		INNER JOIN SKI
		ON RENTAL.SkiID = SKI.SkiID
		WHERE Rental_Number_Of_Days > 10
		GROUP BY Ski_Name, Rental_Number_Of_Days, Rental_Day
		RETURN (0)
	END;

EXECUTE usp_SkiRented ;

--USER DEFINED FUNCTION
--Function will show location of store when you enter the StoreID

CREATE FUNCTION udf_StoreName(@InputID NVARCHAR(2))
RETURNS TABLE
AS 
RETURN (SELECT Store_Location FROM STORE WHERE StoreID = @InputID)
GO

SELECT Store_Location
FROM dbo.udf_StoreName('1')
;
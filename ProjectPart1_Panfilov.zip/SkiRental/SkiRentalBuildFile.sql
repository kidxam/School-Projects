IF NOT EXISTS(SELECT * FROM sys.databases
	WHERE NAME = N'SkiRental')
	CREATE DATABASE SkiRental
GO
USE SkiRental


DECLARE
	@data_path NVARCHAR(256);
SELECT @data_path = 'C:\Users\kidxa\Documents\INFO 3240\Project Build 1\SkiRental\';


IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'EMPLOYEE'
       )
	DROP TABLE EMPLOYEE;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'STORE'
       )
	DROP TABLE STORE;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'CUSTOMER'
       )
	DROP TABLE CUSTOMER;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'SKI'
       )
	DROP TABLE SKI;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'SHIFT'
       )
	DROP TABLE SHIFT;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'RENTAL'
       )
	DROP TABLE RENTAL;
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE NAME = N'OWNER'
       )
	DROP TABLE OWNER;
--
IF EXISTS(

	SELECT *
	FROM sys.tables
	WHERE NAME = N'MANUFACTURER'
       )
	DROP TABLE MANUFACTURER;
--
CREATE TABLE SHIFT
	(ShiftID			INT CONSTRAINT pk_shift PRIMARY KEY,
	Shift_Time			NVARCHAR(10) CONSTRAINT nn_shift_time NOT NULL,
	Shift_Date			NVARCHAR(10) CONSTRAINT nn_shift_date NOT NULL,
	);

CREATE TABLE OWNER
	(OwnerID			INT CONSTRAINT pk_owner PRIMARY KEY,
	Owner_First_Name	NVARCHAR(50) CONSTRAINT nn_owner_first_name NOT NULL,
	Owner_Last_Name		NVARCHAR(50) CONSTRAINT nn_owner_last_name NOT NULL,
	);

CREATE TABLE CUSTOMER
	(CustomerID				INT CONSTRAINT pk_customer PRIMARY KEY,
	Customer_First_Name		NVARCHAR(50) CONSTRAINT nn_customer_first_name NOT NULL,
	Customer_Last_Name		NVARCHAR(50) CONSTRAINT nn_customer_last_name NOT NULL,
	Customer_Email_Address	NVARCHAR(100) CONSTRAINT nn_customer_email_address NOT NULL,
	Customer_Phone_Number	NVARCHAR(20),
	Customer_Street_Address NVARCHAR(50) CONSTRAINT nn_customer_street_Address NOT NULL,
	Customer_Zip_Code		NVARCHAR(10) CONSTRAINT nn_customer_zip_code NOT NULL,
	);

CREATE TABLE MANUFACTURER
	(ManufacturerID		INT CONSTRAINT pk_manufacturer PRIMARY KEY, 
	Manufacturer_Name   NVARCHAR(50) CONSTRAINT nn_manufacturer_name NOT NULL,
	);

CREATE TABLE SKI 
	(SkiID				INT CONSTRAINT pk_ski PRIMARY KEY,
	ManufacturerID		INT CONSTRAINT fk_ski_manufacturer FOREIGN KEY REFERENCES MANUFACTURER(ManufacturerID),
	Ski_Name			NVARCHAR(50) CONSTRAINT nn_ski_name NOT NULL,
	);

CREATE TABLE STORE
	(StoreID			INT CONSTRAINT pk_store PRIMARY KEY,
	OwnerID				INT CONSTRAINT fk_owner_store FOREIGN KEY REFERENCES OWNER(OwnerID),
	Store_Location		NVARCHAR(40) CONSTRAINT nn_store_location NOT NULL,
	);

CREATE TABLE EMPLOYEE 
	(EmployeeID				INT CONSTRAINT pk_employee PRIMARY KEY,
	ShiftID					INT CONSTRAINT fk_employee_shift FOREIGN KEY REFERENCES SHIFT(ShiftID),
	StoreID					INT CONSTRAINT fk_employee_store FOREIGN KEY REFERENCES STORE(StoreID),
	Employee_First_Name		NVARCHAR(50) CONSTRAINT nn_employee_first_name NOT NULL,
	Employee_Last_Name		NVARCHAR(50) CONSTRAINT nn_employee_last_name NOT NULL,
	Employee_Email_Address	NVARCHAR(100) CONSTRAINT nn_employee_email_address NOT NULL,
	Employee_Phone_Number	NVARCHAR(20),
	Employee_Street_Address NVARCHAR(50) CONSTRAINT nn_employee_street_Address NOT NULL,
	Employee_Zip_Code		NVARCHAR(10) CONSTRAINT nn_employee_zip_code NOT NULL,
	);


CREATE TABLE RENTAL 
	(RentalID				INT CONSTRAINT pk_rental PRIMARY KEY,
	EmployeeID				INT CONSTRAINT fk_rental_employee FOREIGN KEY REFERENCES EMPLOYEE(EmployeeID),
	SkiID					INT CONSTRAINT fk_rental_ski FOREIGN KEY REFERENCES SKI(SkiID),
	CustomerID				INT CONSTRAINT fk_rental_customer FOREIGN KEY REFERENCES CUSTOMER(CustomerID),
	Rental_Day				NVARCHAR(10) CONSTRAINT nn_rental_day NOT NULL,
	Rental_Number_Of_Days	NVARCHAR(2) CONSTRAINT nn_rental_number_of_days NOT NULL,
	);


BULK
INSERT STORE
FROM 'C:\Users\kidxa\Documents\INFO 3240\Project Build 1\SkiRental\StoreTable.CSV'
WITH
(
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n'
)
;
--
BULK
INSERT SKI
FROM 'C:\Users\kidxa\Documents\INFO 3240\Project Build 1\SkiRental\SkiTable.CSV'
WITH
(
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n'
)
;
--
BULK
INSERT SHIFT
FROM 'C:\Users\kidxa\Documents\INFO 3240\Project Build 1\SkiRental\ShiftTable.CSV'
WITH
(
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n'
)
;
--
BULK
INSERT RENTAL
FROM 'C:\Users\kidxa\Documents\INFO 3240\Project Build 1\SkiRental\RentalTable.CSV'
WITH
(
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n'
)
;
--
BULK
INSERT Owner
FROM 'C:\Users\kidxa\Documents\INFO 3240\Project Build 1\SkiRental\OwnerTable.CSV'
WITH
(
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n'
)
;
--
BULK
INSERT Manufacturer
FROM 'C:\Users\kidxa\Documents\INFO 3240\Project Build 1\SkiRental\ManufacturerTable.CSV'
WITH
(
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n'
)
;
--
BULK
INSERT Employee
FROM 'C:\Users\kidxa\Documents\INFO 3240\Project Build 1\SkiRental\EmployeeTable.CSV'
WITH
(
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n'
)
;
--
BULK
INSERT CUSTOMER
FROM 'C:\Users\kidxa\Documents\INFO 3240\Project Build 1\SkiRental\CustomerTable.CSV'
WITH
(
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n'
)
;
	